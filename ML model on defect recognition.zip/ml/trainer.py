import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras import layers, models

# Function to load and preprocess images
def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder,filename))
        if img is not None:
            img = cv2.resize(img, (64, 64))  # Resize images to a fixed size
            img = img.astype('float32') / 255  # Normalize pixel values
            images.append(img)
    return images

# Load images from positive and negative folders
positive_images = load_images_from_folder(r'F:\VScode\DEFECTS\Positive')
negative_images = load_images_from_folder(r'F:\VScode\DEFECTS\Negative')

# Create labels for positive and negative images (1 for positive, 0 for negative)
positive_labels = np.ones(len(positive_images))
negative_labels = np.zeros(len(negative_images))

# Combine images and labels
X = np.array(positive_images + negative_images)
y = np.concatenate([positive_labels, negative_labels])

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build a simple CNN model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.MaxPooling2D((2, 2)),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Print model summary
print(model.summary())

# Train the model
print("Training the model...")
history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

# Evaluate the model
print("Evaluating the model...")
test_loss, test_acc = model.evaluate(X_test, y_test)
print('Test accuracy:', test_acc)

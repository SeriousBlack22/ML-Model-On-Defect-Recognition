import os
import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog
from tensorflow.keras.models import load_model

# Function to load and preprocess an image
def load_and_preprocess_image(file_path):
    img = cv2.imread(file_path)
    if img is not None:
        img = cv2.resize(img, (64, 64))  # Resize image to a fixed size
        img = img.astype('float32') / 255  # Normalize pixel values
        return img
    else:
        print("Error: Unable to load the image.")
        return None

# Load the trained model
model = load_model("F:\VScode\ml\crack_detection_model.h5")

# Create a Tkinter window
root = tk.Tk()
root.withdraw()  # Hide the main window

# Ask the user to choose an image file
file_path = filedialog.askopenfilename()

# Load and preprocess the selected image
image = load_and_preprocess_image(file_path)

# If image is loaded successfully, classify it using the model
if image is not None:
    # Expand dimensions to match the input shape expected by the model
    image = np.expand_dims(image, axis=0)
    # Make prediction
    prediction = model.predict(image)
    # Display prediction
    if prediction[0][0] > 0.5:
        print("The image belongs to the positive class (crack).")
    else:
        print("The image belongs to the negative class (non-crack).")
